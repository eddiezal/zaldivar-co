// next.config.js
/** @type {import('next').NextConfig} */
module.exports = {
  experimental: {},
  swcMinify: true,
};

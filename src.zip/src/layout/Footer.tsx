import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-muted-navy text-warm-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Information */}
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-xl font-serif font-semibold mb-4">Zaldivar & Co.</h3>
            <p className="mb-4 text-warm-white/80 max-w-md">
              Leading fractional strategy and technical execution for businesses looking to innovate and grow.
            </p>
            <p className="text-warm-white/80">
              © {new Date().getFullYear()} Zaldivar & Co. All rights reserved.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-medium mb-4">Quick Links</h4>
            <nav>
              <ul className="space-y-2">
                <li>
                  <Link 
                    to="/about" 
                    className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link 
                    to="/services" 
                    className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                  >
                    Services
                  </Link>
                </li>
                <li>
                  <Link 
                    to="/case-studies" 
                    className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                  >
                    Case Studies
                  </Link>
                </li>
                <li>
                  <Link 
                    to="/contact" 
                    className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </nav>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-lg font-medium mb-4">Contact</h4>
            <address className="not-italic">
              <p className="mb-2 text-warm-white/80">
                <span className="block">Email:</span>
                <a 
                  href="mailto:info@zaldivarco.com" 
                  className="text-warm-white hover:text-earthy-taupe transition-colors duration-300"
                >
                  info@zaldivarco.com
                </a>
              </p>
              <p className="mb-2 text-warm-white/80">
                <span className="block">Location:</span>
                <span className="text-warm-white">San Francisco, CA</span>
              </p>
            </address>

            {/* Social Media Links */}
            <div className="mt-4 flex space-x-4">
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                aria-label="LinkedIn"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="24" 
                  height="24" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                >
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                </svg>
              </a>
              <a 
                href="https://twitter.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-warm-white/80 hover:text-warm-white transition-colors duration-300"
                aria-label="Twitter"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="24" 
                  height="24" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                >
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import{f as o}from"./index-BZkcKs8Z.js";import{H as p}from"./Header-DyW3d9t5.js";import"./jsx-runtime-D_zvdyIk.js";import"./Button-Brdg18Zs.js";const l={title:"Example/Header",component:p,tags:["autodocs"],parameters:{layout:"fullscreen"},args:{onLogin:o(),onLogout:o(),onCreateAccount:o()}},e={args:{user:{name:"Jane Doe"}}},r={};var a,s,t;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    user: {
      name: 'Jane Doe'
    }
  }
}`,...(t=(s=e.parameters)==null?void 0:s.docs)==null?void 0:t.source}}};var n,c,m;r.parameters={...r.parameters,docs:{...(n=r.parameters)==null?void 0:n.docs,source:{originalSource:"{}",...(m=(c=r.parameters)==null?void 0:c.docs)==null?void 0:m.source}}};const f=["LoggedIn","LoggedOut"];export{e as LoggedIn,r as LoggedOut,f as __namedExportsOrder,l as default};

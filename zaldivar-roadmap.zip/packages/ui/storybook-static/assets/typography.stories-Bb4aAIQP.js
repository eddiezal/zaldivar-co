import{j as g}from"./jsx-runtime-D_zvdyIk.js";const i=({as:l="p",variant:d="p",className:m,children:c,...h})=>{const u={h1:"text-4xl font-bold",h2:"text-3xl font-semibold",h3:"text-2xl font-medium",p:"text-base",span:"text-sm"};return g.jsx(l,{className:`${u[d]} ${m||""}`,...h,children:c})};i.__docgenInfo={description:"",methods:[],displayName:"Typography",props:{as:{required:!1,tsType:{name:"JSX.IntrinsicElements"},description:"",defaultValue:{value:'"p"',computed:!1}},variant:{required:!1,tsType:{name:"union",raw:'"h1" | "h2" | "h3" | "p" | "span"',elements:[{name:"literal",value:'"h1"'},{name:"literal",value:'"h2"'},{name:"literal",value:'"h3"'},{name:"literal",value:'"p"'},{name:"literal",value:'"span"'}]},description:"",defaultValue:{value:'"p"',computed:!1}}}};const f={title:"Components/Typography",component:i,tags:["autodocs"]},a={args:{as:"h1",children:"This is a Heading 1"}},e={args:{as:"p",children:"This is a paragraph."}};var s,r,t;a.parameters={...a.parameters,docs:{...(s=a.parameters)==null?void 0:s.docs,source:{originalSource:`{
  args: {
    as: "h1",
    children: "This is a Heading 1"
  }
}`,...(t=(r=a.parameters)==null?void 0:r.docs)==null?void 0:t.source}}};var n,o,p;e.parameters={...e.parameters,docs:{...(n=e.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    as: "p",
    children: "This is a paragraph."
  }
}`,...(p=(o=e.parameters)==null?void 0:o.docs)==null?void 0:p.source}}};const y=["Heading1","Paragraph"];export{a as Heading1,e as Paragraph,y as __namedExportsOrder,f as default};

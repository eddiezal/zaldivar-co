// packages/ui/src/components/card/index.ts
export * from "./card";

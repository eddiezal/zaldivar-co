// packages/ui/src/components/modal/index.ts
export * from "./modal";

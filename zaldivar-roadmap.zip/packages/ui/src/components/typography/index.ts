// packages/ui/src/components/typography/index.ts
export * from "./typography";

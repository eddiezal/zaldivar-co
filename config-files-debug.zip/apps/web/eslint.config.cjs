const config = require("@repo/eslint-config");

/** @type {import("eslint").Linter.Config} */
module.exports = config;


/** @type {import("eslint").Linter.Config} */
export default nextJsConfig;
